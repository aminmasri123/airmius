<?php

namespace App\Console\Commands;

use App\Models\Club;
use App\Models\ClubExternalMember;
use App\Models\ClubSubscription;
use App\Models\Invoice;
use App\Models\User;
use App\Models\UserSubscription;
use App\Notifications\SubscriptionEndingSoon;
use App\Notifications\SubscriptionPaymentIssue;
use App\Services\ClubAccessHandoverService;
use App\Support\AppNotification;
use App\Support\ClubPermissions;
use Carbon\CarbonInterface;
use Illuminate\Console\Command;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class SendMembershipAndBillingReminders extends Command
{
    protected $signature = 'airmius:send-membership-billing-reminders
        {--membership-days=30 : Tage vor Ablauf einer Vereinsmitgliedschaft}
        {--invoice-days=7 : Tage vor Fälligkeit einer Rechnung}
        {--subscription-days=14 : Tage vor Ablauf eines Airmius-Abos}';

    protected $description = 'Benachrichtigt Vereine und Sportler über bald endende Mitgliedschaften, Abos und fällige Beitragszahlungen.';

    public function handle(ClubAccessHandoverService $handovers): int
    {
        $membershipCount = $this->notifyExpiringClubMemberships((int) $this->option('membership-days'), $handovers);
        $invoiceCount = $this->notifyDueInvoices((int) $this->option('invoice-days'));
        $subscriptionCount = $this->notifyExpiringSubscriptions((int) $this->option('subscription-days'));
        $paymentIssueCount = $this->notifySubscriptionPaymentIssues();

        $this->info("Erinnerungen: {$membershipCount} Mitgliedschaften, {$invoiceCount} Rechnungen, {$subscriptionCount} Abos, {$paymentIssueCount} Zahlungsprobleme.");

        return self::SUCCESS;
    }

    private function notifyExpiringClubMemberships(int $days, ClubAccessHandoverService $handovers): int
    {
        $today = now()->startOfDay();
        $until = $today->copy()->addDays($days)->endOfDay();
        $sent = 0;

        DB::table('club_user')
            ->join('clubs', 'clubs.id', '=', 'club_user.club_id')
            ->join('users', 'users.id', '=', 'club_user.user_id')
            ->select([
                'club_user.club_id',
                'club_user.user_id',
                'club_user.member_number',
                'club_user.membership_ends_on',
                'clubs.name as club_name',
                'users.name as user_name',
            ])
            ->where('club_user.membership_status', 'active')
            ->whereNull('club_user.membership_end_notified_at')
            ->whereBetween('club_user.membership_ends_on', [$today->toDateString(), $until->toDateString()])
            ->orderBy('club_user.membership_ends_on')
            ->cursor()
            ->each(function ($membership) use (&$sent, $handovers) {
                $date = $this->formatDate($membership->membership_ends_on);
                $club = Club::query()->find((int) $membership->club_id);
                $departing = User::query()->find((int) $membership->user_id);
                $accessReview = $club && $departing
                    ? $handovers->ensure($club, $departing, (string) $membership->membership_ends_on)
                    : null;

                AppNotification::send((int) $membership->user_id, 'club.membership_ending_soon', [
                    'title' => 'Mitgliedschaft läuft bald ab',
                    'body' => "Deine Mitgliedschaft bei {$membership->club_name} endet am {$date}.",
                    'url' => route('auth.settings'),
                    'club_id' => $membership->club_id,
                ]);

                foreach ($this->clubRecipientIds((int) $membership->club_id, ClubPermissions::MEMBERS_MANAGE) as $recipientId) {
                    AppNotification::send($recipientId, 'club.member_membership_ending_soon', [
                        'title' => 'Mitgliedschaft endet bald',
                        'body' => "{$membership->user_name} endet am {$date}.",
                        'url' => route('auth.club-memberships.index'),
                        'club_id' => $membership->club_id,
                        'user_id' => $membership->user_id,
                    ]);
                }

                if ($accessReview !== null) {
                    foreach ($this->accessReviewRecipients((int) $membership->club_id) as $recipient) {
                        AppNotification::sendLocalized(
                            $recipient,
                            'club.role_access_review_due',
                            'organization.notifications.role_access_review_title',
                            'organization.notifications.role_access_review_body',
                            [
                                'user' => $membership->user_name,
                                'date' => $date,
                                'assignments' => count($accessReview->assignment_snapshot),
                                'delegations' => $accessReview->delegation_count,
                            ],
                            [
                                'url' => route('auth.club-memberships.index'),
                                'club_id' => (int) $membership->club_id,
                                'user_id' => (int) $membership->user_id,
                                'access_handover_review_id' => $accessReview->id,
                                'review_due_on' => $accessReview->due_on->toDateString(),
                                'role_assignment_count' => count($accessReview->assignment_snapshot),
                                'delegation_count' => $accessReview->delegation_count,
                                'decision_required' => true,
                                'decision_options' => ['remove', 'assign_successor'],
                            ],
                            [
                                'dedupe_key' => 'club:'.$membership->club_id.':access-review:'.$membership->user_id.':'.$accessReview->due_on->toDateString(),
                                'priority' => 'high',
                            ],
                        );
                    }
                }

                DB::table('club_user')
                    ->where('club_id', $membership->club_id)
                    ->where('user_id', $membership->user_id)
                    ->update(['membership_end_notified_at' => now()]);

                $sent++;
            });

        ClubExternalMember::query()
            ->with('club:id,name,owner_id')
            ->where('membership_status', 'active')
            ->whereNull('membership_end_notified_at')
            ->whereBetween('membership_ends_on', [$today->toDateString(), $until->toDateString()])
            ->orderBy('membership_ends_on')
            ->chunkById(100, function ($externalMembers) use (&$sent) {
                foreach ($externalMembers as $externalMember) {
                    $date = $this->formatDate($externalMember->membership_ends_on);
                    $name = $externalMember->name ?: $externalMember->email;

                    foreach ($this->clubRecipientIds($externalMember->club_id, ClubPermissions::MEMBERS_MANAGE) as $recipientId) {
                        AppNotification::send($recipientId, 'club.external_member_membership_ending_soon', [
                            'title' => 'Externe Mitgliedschaft endet bald',
                            'body' => "{$name} endet am {$date}.",
                            'url' => route('auth.club-memberships.index'),
                            'club_id' => $externalMember->club_id,
                            'external_member_id' => $externalMember->id,
                        ]);
                    }

                    $externalMember->forceFill(['membership_end_notified_at' => now()])->save();
                    $sent++;
                }
            });

        return $sent;
    }

    private function notifyDueInvoices(int $days): int
    {
        $today = now()->startOfDay();
        $until = $today->copy()->addDays($days)->endOfDay();
        $sent = 0;

        Invoice::query()
            ->with(['club:id,name,owner_id', 'user:id,name,email'])
            ->where('status', 'open')
            ->whereNull('due_soon_notified_at')
            ->whereBetween('due_date', [$today, $until])
            ->orderBy('due_date')
            ->chunkById(100, function ($invoices) use (&$sent) {
                foreach ($invoices as $invoice) {
                    $date = $this->formatDate($invoice->due_date);

                    if ($invoice->user_id) {
                        AppNotification::send((int) $invoice->user_id, 'invoice.due_soon', [
                            'title' => 'Beitragszahlung bald fällig',
                            'body' => "{$invoice->title} von {$invoice->club?->name} ist am {$date} fällig.",
                            'url' => route('auth.settings'),
                            'invoice_id' => $invoice->id,
                            'club_id' => $invoice->club_id,
                        ]);
                    }

                    foreach ($this->clubRecipientIds((int) $invoice->club_id, ClubPermissions::FINANCE_VIEW) as $recipientId) {
                        AppNotification::send($recipientId, 'club.invoice_due_soon', [
                            'title' => 'Beitrag bald fällig',
                            'body' => ($invoice->user?->name ?: 'Ein Mitglied')." hat {$invoice->title} am {$date} fällig.",
                            'url' => route('auth.club-memberships.index'),
                            'invoice_id' => $invoice->id,
                            'club_id' => $invoice->club_id,
                        ]);
                    }

                    $invoice->forceFill(['due_soon_notified_at' => now()])->save();
                    $sent++;
                }
            });

        Invoice::query()
            ->with(['club:id,name,owner_id', 'user:id,name,email'])
            ->where('status', 'open')
            ->whereNull('reminder_sent_at')
            ->where('due_date', '<', $today)
            ->orderBy('due_date')
            ->chunkById(100, function ($invoices) use (&$sent) {
                foreach ($invoices as $invoice) {
                    $date = $this->formatDate($invoice->due_date);

                    if ($invoice->user_id) {
                        AppNotification::send((int) $invoice->user_id, 'invoice.overdue', [
                            'title' => 'Beitragszahlung ist überfällig',
                            'body' => "{$invoice->title} von {$invoice->club?->name} war am {$date} fällig.",
                            'url' => route('auth.settings'),
                            'invoice_id' => $invoice->id,
                            'club_id' => $invoice->club_id,
                        ]);
                    }

                    foreach ($this->clubRecipientIds((int) $invoice->club_id, ClubPermissions::FINANCE_VIEW) as $recipientId) {
                        AppNotification::send($recipientId, 'club.invoice_overdue', [
                            'title' => 'Beitrag ist überfällig',
                            'body' => ($invoice->user?->name ?: 'Ein Mitglied')." ist seit {$date} mit {$invoice->title} offen.",
                            'url' => route('auth.club-memberships.index'),
                            'invoice_id' => $invoice->id,
                            'club_id' => $invoice->club_id,
                        ]);
                    }

                    $invoice->forceFill([
                        'status' => 'overdue',
                        'reminder_sent_at' => now(),
                    ])->save();

                    $sent++;
                }
            });

        return $sent;
    }

    private function notifyExpiringSubscriptions(int $days): int
    {
        $today = now()->startOfDay();
        $until = $today->copy()->addDays($days)->endOfDay();
        $sent = 0;

        ClubSubscription::query()
            ->with(['club:id,name,owner_id', 'plan:id,name'])
            ->whereIn('status', ['trialing', 'cancels_at_period_end'])
            ->whereNull('renewal_notified_at')
            ->where(function ($query) use ($today, $until) {
                $query->whereBetween('current_period_ends_at', [$today, $until])
                    ->orWhere(function ($trialQuery) use ($today, $until) {
                        $trialQuery->whereNull('current_period_ends_at')
                            ->whereBetween('trial_ends_at', [$today, $until]);
                    });
            })
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $endsAt = $subscription->current_period_ends_at ?? $subscription->trial_ends_at;
                    $date = $endsAt?->toDateString() ?? '-';

                    foreach ($this->clubRecipientIds((int) $subscription->club_id, ClubPermissions::SUBSCRIPTIONS_VIEW) as $recipientId) {
                        AppNotification::sendLocalized(
                            $recipientId,
                            'club.subscription_ending_soon',
                            'subscription.notifications.ending_title',
                            'subscription.notifications.ending_club_body',
                            [
                                'club' => $subscription->club?->name ?? AppNotification::translatedReplacement('subscription.notifications.club_fallback', 'Club'),
                                'plan' => $subscription->plan?->name ?? AppNotification::translatedReplacement('subscription.email.plan_fallback', 'Airmius plan'),
                                'date' => $date,
                            ],
                            [
                                'url' => route('auth.club-memberships.index'),
                                'club_id' => $subscription->club_id,
                                'subscription_id' => $subscription->id,
                            ],
                            ['dedupe_key' => 'subscription:club:'.$subscription->id.':ending:'.$date],
                        );
                    }
                    foreach ($this->clubRecipientUsers((int) $subscription->club_id, ClubPermissions::SUBSCRIPTIONS_VIEW) as $recipient) {
                        $recipient->notify(new SubscriptionEndingSoon($subscription));
                    }

                    $subscription->forceFill(['renewal_notified_at' => now()])->save();
                    $sent++;
                }
            });

        UserSubscription::query()
            ->with(['user:id,name,email', 'plan:id,name'])
            ->whereIn('status', ['trialing', 'cancels_at_period_end'])
            ->whereNull('renewal_notified_at')
            ->where(function ($query) use ($today, $until) {
                $query->whereBetween('current_period_ends_at', [$today, $until])
                    ->orWhere(function ($trialQuery) use ($today, $until) {
                        $trialQuery->whereNull('current_period_ends_at')
                            ->whereBetween('trial_ends_at', [$today, $until]);
                    });
            })
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $endsAt = $subscription->current_period_ends_at ?? $subscription->trial_ends_at;
                    $date = $endsAt?->toDateString() ?? '-';

                    AppNotification::sendLocalized(
                        (int) $subscription->user_id,
                        'user.subscription_ending_soon',
                        'subscription.notifications.ending_title',
                        'subscription.notifications.ending_user_body',
                        [
                            'plan' => $subscription->plan?->name ?? AppNotification::translatedReplacement('subscription.email.plan_fallback', 'Airmius plan'),
                            'date' => $date,
                        ],
                        [
                            'url' => route('guest.pricing'),
                            'subscription_id' => $subscription->id,
                        ],
                        ['dedupe_key' => 'subscription:user:'.$subscription->id.':ending:'.$date],
                    );
                    if ($subscription->user?->email) {
                        $subscription->user->notify(new SubscriptionEndingSoon($subscription));
                    }

                    $subscription->forceFill(['renewal_notified_at' => now()])->save();
                    $sent++;
                }
            });

        return $sent;
    }

    private function notifySubscriptionPaymentIssues(): int
    {
        $sent = 0;
        $today = now()->startOfDay();

        ClubSubscription::query()
            ->with(['club.owner', 'club.users', 'plan:id,name'])
            ->where('status', 'trialing')
            ->whereNotNull('trial_ends_at')
            ->where('trial_ends_at', '<', $today)
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $subscription->forceFill(['status' => 'past_due'])->save();
                    $sent += $this->sendPaymentIssueForSubscription($subscription);
                }
            });

        UserSubscription::query()
            ->with(['user:id,name,email', 'plan:id,name'])
            ->where('status', 'trialing')
            ->whereNotNull('trial_ends_at')
            ->where('trial_ends_at', '<', $today)
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $subscription->forceFill(['status' => 'past_due'])->save();
                    $sent += $this->sendPaymentIssueForSubscription($subscription);
                }
            });

        ClubSubscription::query()
            ->with(['club.owner', 'club.users', 'plan:id,name'])
            ->where('status', 'past_due')
            ->whereNull('payment_issue_email_sent_at')
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $sent += $this->sendPaymentIssueForSubscription($subscription);
                }
            });

        UserSubscription::query()
            ->with(['user:id,name,email', 'plan:id,name'])
            ->where('status', 'past_due')
            ->whereNull('payment_issue_email_sent_at')
            ->chunkById(100, function ($subscriptions) use (&$sent) {
                foreach ($subscriptions as $subscription) {
                    $sent += $this->sendPaymentIssueForSubscription($subscription);
                }
            });

        return $sent;
    }

    private function sendPaymentIssueForSubscription(ClubSubscription|UserSubscription $subscription): int
    {
        if ($subscription->payment_issue_email_sent_at) {
            return 0;
        }

        $recipients = $subscription instanceof UserSubscription
            ? collect([$subscription->user])->filter()
            : $this->clubRecipientUsers((int) $subscription->club_id, ClubPermissions::SUBSCRIPTIONS_VIEW);

        foreach ($recipients as $recipient) {
            if ($recipient?->email) {
                $recipient->notify(new SubscriptionPaymentIssue($subscription));
            }
        }

        if ($subscription instanceof UserSubscription) {
            AppNotification::sendLocalized(
                (int) $subscription->user_id,
                'user.subscription_payment_issue',
                'subscription.notifications.payment_issue_title',
                'subscription.notifications.payment_issue_user_body',
                [
                    'plan' => $subscription->plan?->name ?? AppNotification::translatedReplacement('subscription.email.plan_fallback', 'Airmius plan'),
                ],
                [
                    'url' => route('guest.pricing'),
                    'subscription_id' => $subscription->id,
                ],
                [
                    'dedupe_key' => 'subscription:user:'.$subscription->id.':payment-issue',
                    'priority' => 'high',
                ],
            );
        } else {
            foreach ($this->clubRecipientIds((int) $subscription->club_id, ClubPermissions::SUBSCRIPTIONS_VIEW) as $recipientId) {
                AppNotification::sendLocalized(
                    $recipientId,
                    'club.subscription_payment_issue',
                    'subscription.notifications.payment_issue_title',
                    'subscription.notifications.payment_issue_club_body',
                    [
                        'club' => $subscription->club?->name ?? AppNotification::translatedReplacement('subscription.notifications.club_fallback', 'Club'),
                        'plan' => $subscription->plan?->name ?? AppNotification::translatedReplacement('subscription.email.plan_fallback', 'Airmius plan'),
                    ],
                    [
                        'url' => route('guest.pricing'),
                        'club_id' => $subscription->club_id,
                        'subscription_id' => $subscription->id,
                    ],
                    [
                        'dedupe_key' => 'subscription:club:'.$subscription->id.':payment-issue',
                        'priority' => 'high',
                    ],
                );
            }
        }

        $subscription->forceFill(['payment_issue_email_sent_at' => now()])->save();

        return 1;
    }

    private function clubRecipientIds(int $clubId, string $permission): array
    {
        return $this->clubRecipientUsers($clubId, $permission)
            ->pluck('id')
            ->map(fn ($id) => (int) $id)
            ->all();
    }

    /** @return Collection<int, User> */
    private function clubRecipientUsers(int $clubId, string $permission): Collection
    {
        $club = Club::query()->select('id', 'owner_id')->find($clubId);

        if (! $club) {
            return collect();
        }

        return $club->users()
            ->get()
            ->push($club->owner)
            ->filter()
            ->unique('id')
            ->filter(fn (User $user) => ClubPermissions::allows($club, $user, $permission))
            ->values();
    }

    /** @return Collection<int, User> */
    private function accessReviewRecipients(int $clubId)
    {
        $club = Club::query()->select('id', 'owner_id')->find($clubId);
        if (! $club) {
            return collect();
        }

        return $club->users()
            ->where(function ($query) {
                $query->whereNull('club_user.membership_status')
                    ->orWhere('club_user.membership_status', 'active');
            })
            ->get(['users.id', 'users.language'])
            ->push(User::query()->select(['id', 'language'])->find($club->owner_id))
            ->filter()
            ->unique('id')
            ->filter(fn (User $user) => ClubPermissions::editableBy($club, $user))
            ->values();
    }

    private function formatDate(CarbonInterface|string|null $value): string
    {
        if (! $value) {
            return '-';
        }

        return Carbon::parse($value)->format('d.m.Y');
    }
}
