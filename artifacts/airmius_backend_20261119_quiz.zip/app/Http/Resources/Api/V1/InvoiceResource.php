<?php

namespace App\Http\Resources\Api\V1;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class InvoiceResource extends JsonResource
{
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'club_id' => $this->club_id,
            'team_id' => $this->team_id,
            'club_budget_id' => $this->club_budget_id,
            'club_department_id' => $this->club_department_id,
            'club_project_id' => $this->club_project_id,
            'club_cost_center_id' => $this->club_cost_center_id,
            'user_id' => $this->user_id,
            'membership_user_id' => $this->membership_user_id,
            'club_external_member_id' => $this->club_external_member_id,
            'number' => $this->number,
            'title' => $this->title,
            'description' => $this->description,
            'amount' => $this->amount,
            ...$this->resource->balancePayload(),
            'status' => $this->status,
            'status_label' => $this->statusLabel(),
            'source' => $this->source,
            'business_year_period_id' => $this->business_year_period_id,
            'business_year_period' => $this->whenLoaded('businessYearPeriod', fn () => $this->periodReference($this->businessYearPeriod)),
            'contribution_year_period_id' => $this->contribution_year_period_id,
            'contribution_year_period' => $this->whenLoaded('contributionYearPeriod', fn () => $this->periodReference($this->contributionYearPeriod)),
            'billing_period_start' => $this->billing_period_start?->toDateString(),
            'billing_period_end' => $this->billing_period_end?->toDateString(),
            'due_date' => $this->due_date?->toJSON(),
            'issued_at' => $this->issued_at?->toJSON(),
            'paid_at' => $this->paid_at?->toJSON(),
            'reminder_sent_at' => $this->reminder_sent_at?->toJSON(),
            'club' => new ClubResource($this->whenLoaded('club')),
            'user' => new UserResource($this->whenLoaded('user')),
            'member' => $this->memberPayload(),
            'payments' => $this->whenLoaded('paymentHistory', fn () => $this->resource->paymentHistoryPayload()),
            'created_at' => $this->created_at?->toJSON(),
            'updated_at' => $this->updated_at?->toJSON(),
        ];
    }

    private function memberPayload(): ?array
    {
        if ($this->membershipUser) {
            return [
                'id' => $this->membershipUser->id,
                'name' => $this->membershipUser->name,
                'email' => $this->membershipUser->email,
                'is_external' => false,
            ];
        }

        if ($this->externalMember) {
            return [
                'id' => $this->externalMember->id,
                'name' => $this->externalMember->name,
                'email' => $this->externalMember->email,
                'is_external' => true,
            ];
        }

        return null;
    }

    private function periodReference($period): ?array
    {
        return $period ? [
            'id' => $period->id,
            'type' => $period->type,
            'name' => $period->name,
            'starts_on' => $period->starts_on?->toDateString(),
            'ends_on' => $period->ends_on?->toDateString(),
        ] : null;
    }
}
