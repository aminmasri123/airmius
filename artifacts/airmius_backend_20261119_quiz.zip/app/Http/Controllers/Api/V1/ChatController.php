<?php

namespace App\Http\Controllers\Api\V1;

use App\Events\ChatTyping;
use App\Events\MessageDeleted;
use App\Events\MessageReactionUpdated;
use App\Events\MessageReceiptsUpdated;
use App\Http\Controllers\Controller;
use App\Http\Controllers\ConversationController as WebConversationController;
use App\Http\Resources\Api\V1\ConversationResource;
use App\Http\Resources\Api\V1\MessageResource;
use App\Models\Conversation;
use App\Models\ConversationInvitation;
use App\Models\Message;
use App\Models\MessageHide;
use App\Models\MessageReaction;
use App\Models\MessageReceipt;
use App\Models\Team;
use App\Models\User;
use App\Services\ApiUserPayloadLoader;
use App\Services\ChatLatestMessageLoader;
use App\Services\ChatService;
use App\Services\ModerationService;
use App\Support\AppNotification;
use App\Support\GuardianConsentState;
use App\Support\Performance\ResourceReadCache;
use App\Support\UploadStorage;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ChatController extends Controller
{
    public function __construct(
        private readonly ChatService $chatService,
        private readonly ModerationService $moderation,
        private readonly ChatLatestMessageLoader $latestMessageLoader,
    ) {}

    public function index(Request $request)
    {
        $this->authorizeGuardianConsent($request);

        $request->validate([
            'team_id' => ['nullable', 'integer', 'exists:teams,id'],
        ]);

        $userId = $request->user()->id;
        $conversationsQuery = $request->user()
            ->conversations()
            ->visibleToUser($userId)
            ->with(['users', 'team', 'owner'])
            ->withCount([
                'messages',
                'messages as unread_messages_count' => fn ($query) => $query
                    ->visibleSinceGroupJoin($userId)
                    ->whereHas('receipts', fn ($receipts) => $receipts
                        ->where('user_id', $userId)
                        ->whereNull('read_at')),
            ])
            ->orderByDesc('conversations.updated_at');

        if ($request->filled('team_id')) {
            $conversationsQuery->where(
                'conversations.team_id',
                (int) $request->input('team_id'),
            );
        }

        $conversations = $conversationsQuery->paginate($this->perPage($request));
        $this->latestMessageLoader->attach(
            $conversations->getCollection(),
            (int) $request->user()->id,
            ['sender', 'receipts', 'attachments.file', 'reactions.user'],
        );

        $users = $conversations->getCollection()->flatMap(function ($conversation) {
            $latest = $conversation->latestVisibleMessage;

            return $conversation->users
                ->concat([$conversation->owner, $latest?->sender])
                ->concat($latest?->reactions->pluck('user') ?? []);
        })->filter();
        app(ApiUserPayloadLoader::class)->load($users);

        return ResourceReadCache::render(
            $request,
            fn () => ConversationResource::collection($conversations)->toResponse($request),
        );
    }

    public function invitations(Request $request)
    {
        $invitations = ConversationInvitation::query()
            ->where('recipient_id', $request->user()->id)
            ->where('status', 'pending')
            ->with([
                'inviter:id,name',
                'conversation' => fn ($query) => $query->with(['users:id,name', 'owner:id,name']),
            ])
            ->latest('id')
            ->get()
            ->map(fn (ConversationInvitation $invitation) => [
                'id' => $invitation->id,
                'status' => $invitation->status,
                'created_at' => optional($invitation->created_at)->toIso8601String(),
                'inviter' => $invitation->inviter ? [
                    'id' => $invitation->inviter->id,
                    'name' => $invitation->inviter->name,
                ] : null,
                'conversation' => $invitation->conversation ? [
                    'id' => $invitation->conversation->id,
                    'name' => $invitation->conversation->name,
                    'description' => $invitation->conversation->description,
                    'members_count' => $invitation->conversation->users->count(),
                ] : null,
            ])
            ->values();

        return response()->json(['data' => $invitations]);
    }

    public function show(Request $request, string $conversation)
    {
        $conversation = Conversation::query()->visibleToUser((int) $request->user()->id)->where(ctype_digit($conversation) ? 'id' : 'public_id', $conversation)
            ->whereHas('users', fn ($query) => $query->where('users.id', $request->user()->id))->firstOrFail();
        $this->authorizeGuardianConsent($request);
        $this->authorizeParticipant($conversation, $request);

        return new ConversationResource(
            $conversation->loadMissing(['users', 'team', 'owner'])->loadCount('messages')
        );
    }

    public function store(Request $request)
    {
        $this->authorizeGuardianConsent($request);

        $data = $request->validate([
            'type' => ['required', 'in:direct,group,team'],
            'club_id' => ['nullable', 'exists:clubs,id'],
            'team_id' => ['nullable', 'required_if:type,team', 'exists:teams,id'],
            'participant_ids' => ['nullable', 'array'],
            'participant_ids.*' => ['integer', 'exists:users,id'],
            'name' => ['nullable', 'string', 'max:120'],
            'description' => ['nullable', 'string', 'max:500'],
            'message' => ['nullable', 'string', 'max:4000'],
            'scheduled_at' => ['nullable', 'date'],
        ]);

        $conversation = DB::transaction(function () use ($request, $data) {
            $scheduledAt = filled($data['scheduled_at'] ?? null)
                ? Carbon::parse($data['scheduled_at'])
                : null;
            $participantIds = collect($data['participant_ids'] ?? [])
                ->push($request->user()->id)
                ->map(fn ($id) => (int) $id)
                ->unique()
                ->values();

            abort_if($data['type'] === 'direct' && $participantIds->count() !== 2, 422);
            abort_if($data['type'] === 'group' && $participantIds->count() < 3, 422);

            if ($data['type'] === 'team') {
                $team = Team::query()
                    ->whereHas('users', fn ($query) => $query->where('users.id', $request->user()->id))
                    ->findOrFail($data['team_id']);

                $conversation = Conversation::firstOrCreate(
                    ['type' => 'team', 'team_id' => $team->id],
                    [
                        'club_id' => $team->club_id,
                        'name' => filled($data['name'] ?? null) ? trim($data['name']) : null,
                        'description' => filled($data['description'] ?? null) ? trim($data['description']) : null,
                        'scheduled_at' => $scheduledAt,
                    ]
                );
                $conversation->fill([
                    'name' => filled($data['name'] ?? null) ? trim($data['name']) : $conversation->name,
                    'description' => filled($data['description'] ?? null) ? trim($data['description']) : $conversation->description,
                    'scheduled_at' => $scheduledAt ?? $conversation->scheduled_at,
                ])->save();
                $this->attachNewParticipantsWithJoinedAt(
                    $conversation,
                    $team->users()->pluck('users.id')->push($request->user()->id)
                );
            } elseif ($data['type'] === 'direct') {
                $this->authorizeClubContext($data['club_id'] ?? null, $participantIds);
                $recipient = User::findOrFail($participantIds->first(fn ($id) => $id !== $request->user()->id));

                abort_unless($recipient->allowsDirectMessagesFrom($request->user()), 403, __('server.chat.direct_messages_forbidden'));

                $conversation = Conversation::query()
                    ->where('type', 'direct')
                    ->whereHas('users', fn ($query) => $query->where('users.id', $request->user()->id))
                    ->whereHas('users', fn ($query) => $query->where('users.id', $recipient->id))
                    ->first();

                if (! $conversation) {
                    $conversation = Conversation::create([
                        'type' => 'direct',
                        'club_id' => $data['club_id'] ?? null,
                        'scheduled_at' => $scheduledAt,
                    ]);
                    $conversation->users()->attach($this->participantsWithJoinedAt($participantIds));
                } elseif ($scheduledAt) {
                    $conversation->forceFill(['scheduled_at' => $scheduledAt])->save();
                }
            } else {
                $this->authorizeClubContext($data['club_id'] ?? null, $participantIds);
                $this->authorizeGroupParticipants($request, $participantIds->reject(fn ($id) => (int) $id === $request->user()->id));

                $conversation = Conversation::create([
                    'type' => 'group',
                    'club_id' => $data['club_id'] ?? null,
                    'owner_id' => $request->user()->id,
                    'name' => filled($data['name'] ?? null) ? trim($data['name']) : null,
                    'description' => filled($data['description'] ?? null) ? trim($data['description']) : null,
                    'scheduled_at' => $scheduledAt,
                ]);
                $conversation->users()->attach($this->participantsWithJoinedAt($participantIds));
                $conversation->users()->updateExistingPivot($request->user()->id, [
                    'role' => Conversation::ROLE_OWNER,
                ]);
            }

            if (! empty($data['message'])) {
                $message = $scheduledAt && $scheduledAt->isFuture()
                    ? $this->chatService->scheduleMessage($request->user(), $conversation, $data['message'], $scheduledAt)
                    : $this->chatService->sendMessage($request->user(), $conversation->id, $data['message']);
                $this->moderation->flagIfNeeded($message, $message->message, $request->user()->id);
            }

            return $conversation;
        });

        return (new ConversationResource(
            $conversation->fresh()->loadMissing(['users', 'team', 'owner'])->loadCount('messages')
        ))->response()->setStatusCode(201);
    }

    public function messages(Request $request, Conversation $conversation)
    {
        $this->authorizeGuardianConsent($request);
        $this->authorizeParticipant($conversation, $request);

        $messages = $conversation->messages()
            ->visibleSinceGroupJoin((int) $request->user()->id)
            ->where('moderation_status', '!=', 'removed')
            ->where('status', '!=', 'scheduled')
            ->whereDoesntHave('hides', fn ($query) => $query->where('user_id', $request->user()->id))
            ->with(['sender', 'receipts', 'attachments.file', 'reactions.user'])
            ->latest()
            ->paginate($this->perPage($request));

        $scheduledMessages = $conversation->messages()
            ->where('sender_id', $request->user()->id)
            ->where('status', 'scheduled')
            ->whereNotNull('scheduled_at')
            ->with(['sender', 'receipts', 'attachments.file', 'reactions.user'])
            ->orderBy('scheduled_at')
            ->get();

        return MessageResource::collection($messages)->additional([
            'chat' => [
                'typing_users' => $this->typingUsers($conversation, $request),
                'scheduled_messages' => MessageResource::collection($scheduledMessages),
            ],
        ]);
    }

    /**
     * Resolve a protected message deep link without exposing messages that the
     * current participant has hidden or could not see when joining a group.
     */
    public function message(Request $request, Message $message)
    {
        $this->authorizeGuardianConsent($request);
        $this->authorizeMessageAccess($message, $request);

        abort_if(
            $message->hides()->where('user_id', $request->user()->id)->exists(),
            404,
            __('server.chat.message_unavailable')
        );

        return new MessageResource(
            $message->loadMissing([
                'sender',
                'conversation',
                'receipts',
                'attachments.file',
                'reactions.user',
            ])
        );
    }

    public function sendMessage(Request $request, Conversation $conversation)
    {
        $this->authorizeGuardianConsent($request);
        $this->authorizeParticipant($conversation, $request);
        abort_unless($conversation->canSendMessages((int) $request->user()->id), 403, __('server.chat.posting_restricted'));

        $data = $request->validate([
            'message' => ['nullable', 'required_without:attachments', 'string', 'max:4000'],
            'attachments' => ['nullable', 'array', 'max:5'],
            'attachments.*' => ['file', 'max:10240'],
        ]);

        if ($conversation->type === 'direct') {
            $recipient = $conversation->users()
                ->where('users.id', '!=', $request->user()->id)
                ->first();

            abort_unless($recipient?->allowsDirectMessagesFrom($request->user()), 403, __('server.chat.direct_messages_forbidden'));
        }

        $message = $this->chatService->sendMessage(
            $request->user(),
            $conversation->id,
            $data['message'] ?? null,
            $request->file('attachments', [])
        );

        $this->moderation->flagIfNeeded($message, $message->message, $request->user()->id);

        $sender = $request->user();
        $conversation->users()
            ->where('users.id', '!=', $sender->id)
            ->get()
            ->each(function (User $recipient) use ($conversation, $message, $sender) {
                if ($this->recipientHasMutedConversation($recipient)) {
                    return;
                }

                AppNotification::sendLocalized($recipient, 'chat.message',
                    'server.chat.notifications.message_title',
                    $message->message ? null : 'server.chat.notifications.attachment',
                    ['sender' => $sender->name], [
                        'body' => $message->message ? str($message->message)->limit(120)->toString() : null,
                        'url' => route('auth.conversations.index', ['conversation' => $conversation->id]),
                        'actor_id' => $sender->id,
                        'actor_name' => $sender->name,
                        'conversation_id' => $conversation->id,
                        'message_id' => $message->id,
                    ], [
                        'dedupe_key' => 'chat-message:'.$message->id,
                    ]);
            });

        return (new MessageResource(
            $message->loadMissing(['sender', 'receipts', 'attachments.file', 'reactions.user'])
        ))->response()->setStatusCode(201);
    }

    public function typing(Request $request, Conversation $conversation)
    {
        $this->authorizeParticipant($conversation, $request);

        $data = $request->validate([
            'typing' => ['required', 'boolean'],
        ]);

        $cacheKey = $this->typingCacheKey($conversation->id, $request->user()->id);
        if ((bool) $data['typing']) {
            Cache::put($cacheKey, true, now()->addSeconds(8));
        } else {
            Cache::forget($cacheKey);
        }

        broadcast(new ChatTyping($conversation, $request->user(), (bool) $data['typing']))->toOthers();

        return response()->json([
            'data' => [
                'conversation_id' => $conversation->id,
                'typing' => (bool) $data['typing'],
                'typing_users' => $this->typingUsers($conversation, $request),
            ],
        ]);
    }

    public function markRead(Request $request, Conversation $conversation)
    {
        $this->authorizeParticipant($conversation, $request);

        $messageIds = MessageReceipt::query()
            ->where('user_id', $request->user()->id)
            ->whereNull('read_at')
            ->whereHas('message', fn ($query) => $query
                ->where('conversation_id', $conversation->id)
                ->visibleSinceGroupJoin((int) $request->user()->id))
            ->pluck('message_id')
            ->all();

        MessageReceipt::query()
            ->whereIn('message_id', $messageIds)
            ->where('user_id', $request->user()->id)
            ->update([
                'delivered_at' => now(),
                'read_at' => now(),
            ]);

        $request->user()
            ->appNotifications()
            ->where('type', 'chat.message')
            ->where('read', false)
            ->where('data->conversation_id', $conversation->id)
            ->update(['read' => true]);

        if ($messageIds) {
            $this->broadcastSafely(fn () => broadcast(new MessageReceiptsUpdated($conversation, $messageIds))->toOthers());
        }

        return response()->json([
            'data' => [
                'conversation_id' => $conversation->id,
                'read_message_ids' => $messageIds,
                'read_count' => count($messageIds),
            ],
        ]);
    }

    public function react(Request $request, Message $message)
    {
        $this->authorizeMessageAccess($message, $request);

        $data = $request->validate([
            'reaction' => ['required', 'in:like,heart,ok'],
        ]);

        $reaction = MessageReaction::query()
            ->where('message_id', $message->id)
            ->where('user_id', $request->user()->id)
            ->first();

        if ($reaction?->reaction === $data['reaction']) {
            $reaction->delete();
        } else {
            MessageReaction::updateOrCreate(
                ['message_id' => $message->id, 'user_id' => $request->user()->id],
                ['reaction' => $data['reaction']]
            );
        }

        $message->load('reactions.user');
        $this->broadcastSafely(fn () => broadcast(new MessageReactionUpdated($message))->toOthers());

        return response()->json([
            'success' => true,
            'reactions' => $message->reactions,
        ]);
    }

    public function hideForMe(Request $request, Message $message)
    {
        $this->authorizeMessageAccess($message, $request);

        MessageHide::firstOrCreate([
            'message_id' => $message->id,
            'user_id' => $request->user()->id,
        ]);

        return response()->json(['success' => true]);
    }

    public function deleteMessage(Request $request, Message $message)
    {
        $this->authorizeMessageAccess($message, $request);
        abort_unless($message->sender_id === $request->user()->id || $request->user()->can('user.manage'), 403);
        abort_if($message->receipts()->whereNotNull('read_at')->exists(), 422, __('server.chat.message_already_read'));

        $message->load('attachments.file');

        foreach ($message->attachments as $attachment) {
            if ($attachment->file?->path) {
                foreach (array_filter([$attachment->file->path, $attachment->file->thumbnail_path]) as $path) {
                    Storage::disk(UploadStorage::disk($path))->delete($path);
                }
            }

            $attachment->file?->delete();
            $attachment->delete();
        }

        $message->delete();
        $this->broadcastSafely(fn () => broadcast(new MessageDeleted($message))->toOthers());

        return response()->json(['success' => true]);
    }

    public function sendScheduledNow(Request $request, Message $message)
    {
        $this->authorizeMessageAccess($message, $request);
        abort_unless($message->sender_id === $request->user()->id, 403);
        abort_unless($message->status === 'scheduled', 422);

        $published = $this->chatService->publishScheduledMessage($message);
        abort_unless($published, 404);

        return (new MessageResource($published))->response()->setStatusCode(201);
    }

    public function updateConversation(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->update($request, $conversation);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function muteConversation(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->mute($request, $conversation);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function leaveConversation(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->leave($request, $conversation);

        return response()->json(['message' => __('server.chat.left')]);
    }

    public function clearConversation(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->clear($request, $conversation);

        return response()->json(['message' => __('server.chat.cleared')]);
    }

    public function inviteMembers(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->addMembers($request, $conversation);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function acceptInvitation(Request $request, ConversationInvitation $invitation)
    {
        app(WebConversationController::class)->acceptInvitation($request, $invitation);

        return new ConversationResource($this->conversationPayload($invitation->conversation));
    }

    public function declineInvitation(Request $request, ConversationInvitation $invitation)
    {
        app(WebConversationController::class)->declineInvitation($request, $invitation);

        return response()->json(['message' => __('server.chat.invitation_declined')]);
    }

    public function removeMember(Request $request, Conversation $conversation, User $user)
    {
        app(WebConversationController::class)->removeMember($request, $conversation, $user);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function transferOwner(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->transferOwner($request, $conversation);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function updateMemberRole(Request $request, Conversation $conversation, User $user)
    {
        app(WebConversationController::class)->updateMemberRole($request, $conversation, $user);

        return new ConversationResource($this->conversationPayload($conversation));
    }

    public function destroyConversation(Request $request, Conversation $conversation)
    {
        app(WebConversationController::class)->destroy($request, $conversation);

        return response()->json(['message' => __('server.chat.group_deleted')]);
    }

    private function conversationPayload(Conversation $conversation): Conversation
    {
        return $conversation->fresh()
            ->loadMissing(['users', 'team', 'owner'])
            ->loadCount('messages');
    }

    private function authorizeParticipant(Conversation $conversation, Request $request): void
    {
        abort_unless(
            $conversation->users()->where('users.id', $request->user()->id)->exists(),
            403
        );
    }

    private function authorizeGuardianConsent(Request $request): void
    {
        GuardianConsentState::sync($request->user());
        abort_if($request->user()->fresh()->hasRole('minor_pending_consent'), 403, __('server.guardian.consent_required'));
    }

    private function authorizeClubContext(?int $clubId, $participantIds): void
    {
        if (! $clubId) {
            return;
        }

        $participantIds = collect($participantIds)
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        $activeMembers = DB::table('club_user')
            ->where('club_id', $clubId)
            ->whereIn('user_id', $participantIds)
            ->where(function ($query) {
                $query->whereNull('membership_status')
                    ->orWhere('membership_status', 'active');
            })
            ->distinct()
            ->count('user_id');

        abort_unless($activeMembers === $participantIds->count(), 422, __('server.chat.club_context_members_only'));
    }

    private function participantsWithJoinedAt($participantIds): array
    {
        $joinedAt = now();

        return collect($participantIds)
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->mapWithKeys(fn ($id) => [$id => ['joined_at' => $joinedAt]])
            ->all();
    }

    private function attachNewParticipantsWithJoinedAt(Conversation $conversation, $participantIds): void
    {
        $participantIds = collect($participantIds)
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        if ($participantIds->isEmpty()) {
            return;
        }

        $existingIds = $conversation->users()
            ->whereIn('users.id', $participantIds)
            ->pluck('users.id')
            ->map(fn ($id) => (int) $id);

        $newParticipantIds = $participantIds->diff($existingIds)->values();

        if ($newParticipantIds->isNotEmpty()) {
            $conversation->users()->syncWithoutDetaching($this->participantsWithJoinedAt($newParticipantIds));
        }
    }

    private function authorizeGroupParticipants(Request $request, $participantIds): void
    {
        $participantIds = collect($participantIds)
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        if ($participantIds->isEmpty()) {
            return;
        }

        $participants = User::query()
            ->whereIn('id', $participantIds)
            ->get()
            ->keyBy('id');

        abort_if($participants->count() !== $participantIds->count(), 422, __('server.chat.participants_missing'));

        foreach ($participants as $participant) {
            abort_unless(
                $request->user()->isFriendsWith($participant) && $participant->allowsDirectMessagesFrom($request->user()),
                403,
                __('server.chat.group_friends_only')
            );
        }
    }

    private function authorizeMessageAccess(Message $message, Request $request): void
    {
        $conversation = $message->conversation;
        $this->authorizeParticipant($conversation, $request);

        abort_if($message->moderation_status === 'removed', 404, __('server.chat.message_unavailable'));

        $joinedAt = $this->groupJoinedAt($conversation, $request);
        abort_if($joinedAt && $message->created_at->lessThan($joinedAt), 403);

        $clearedMessageId = DB::table('conversation_users')
            ->where('conversation_id', $conversation->id)
            ->where('user_id', $request->user()->id)
            ->value('cleared_message_id');

        abort_if($clearedMessageId !== null && $message->id <= $clearedMessageId, 404, __('server.chat.message_unavailable'));
    }

    private function groupJoinedAt(Conversation $conversation, Request $request): ?string
    {
        if ($conversation->type !== 'group') {
            return null;
        }

        return DB::table('conversation_users')
            ->where('conversation_id', $conversation->id)
            ->where('user_id', $request->user()->id)
            ->value('joined_at');
    }

    private function recipientHasMutedConversation(User $recipient): bool
    {
        $mutedUntil = $recipient->pivot?->muted_until;

        return $mutedUntil && Carbon::parse($mutedUntil)->isFuture();
    }

    private function broadcastSafely(callable $callback): void
    {
        try {
            $callback();
        } catch (\Throwable) {
            // Realtime failures must not break mobile chat actions.
        }
    }

    private function perPage(Request $request): int
    {
        return min(max((int) $request->integer('per_page', 25), 1), 100);
    }

    private function typingUsers(Conversation $conversation, Request $request): array
    {
        return $conversation->users()
            ->where('users.id', '!=', $request->user()->id)
            ->get(['users.id', 'users.name'])
            ->filter(fn ($user) => Cache::has($this->typingCacheKey($conversation->id, $user->id)))
            ->map(fn ($user) => [
                'id' => $user->id,
                'name' => $user->name,
            ])
            ->values()
            ->all();
    }

    private function typingCacheKey(int $conversationId, int $userId): string
    {
        return "chat:typing:{$conversationId}:{$userId}";
    }
}
