<?php

namespace App\Http\Controllers;

use App\Models\OutfitDelivery;
use App\Models\OutfitStyleProfile;
use App\Models\OutfitSubscription;
use App\Models\OutfitSubscriptionPlan;
use App\Models\Setting;
use App\Models\Sport;
use App\Models\User;
use App\Services\OutfitInvoiceService;
use App\Support\AppNotification;
use App\Support\PaymentWebhookVerifier;
use App\Support\Roles;
use App\Support\UploadStorage;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;
use Throwable;

class OutfitSubscriptionController extends Controller
{
    public function index(Request $request)
    {
        $payload = [
            'plans' => OutfitSubscriptionPlan::query()
                ->with('sponsor:id,name,logo,logo_light,logo_dark,website')
                ->where('is_active', true)
                ->where('is_public', true)
                ->orderBy('sort_order')
                ->orderBy('monthly_price_cents')
                ->get()
                ->map(fn (OutfitSubscriptionPlan $plan) => $this->planPayload($plan)),
            'styleProfile' => $request->user()
                ->outfitStyleProfile()
                ->first(),
            'subscriptions' => $request->user()
                ->outfitSubscriptions()
                ->with(['plan.sponsor:id,name,logo,logo_light,logo_dark,website', 'sponsor:id,name,logo,logo_light,logo_dark,website', 'deliveries' => fn ($query) => $query->latest()->limit(6)])
                ->latest()
                ->get()
                ->map(fn (OutfitSubscription $subscription) => $this->subscriptionPayload($subscription)),
            'heroImageUrl' => UploadStorage::url(Setting::valueFor('outfit_subscription_hero_image', '/images/marketplace/airmius_outfit_abo.webp')),
            'sports' => Sport::query()
                ->where('is_active', true)
                ->orderBy('sort_order')
                ->orderBy('name')
                ->get(['id', 'name', 'slug', 'category']),
            'contractRules' => $this->contractRules(null),
        ];

        if ($request->expectsJson()) {
            return response()->json(['data' => $payload]);
        }

        return Inertia::render('Auth/Dashboard/OutfitSubscriptions/Index', $payload);
    }

    public function updateProfile(Request $request)
    {
        $data = $request->validate([
            'sport_focus' => ['nullable', 'string', 'max:120'],
            'sizes' => ['nullable', 'array'],
            'sizes.*' => ['nullable', 'string', 'max:20'],
            'fit_preference' => ['nullable', 'string', 'max:60'],
            'colors' => ['nullable', 'array'],
            'colors.*' => ['nullable', 'string', 'max:40'],
            'excluded_colors' => ['nullable', 'array'],
            'excluded_colors.*' => ['nullable', 'string', 'max:40'],
            'brand_style' => ['nullable', 'string', 'max:60'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ]);

        $profile = OutfitStyleProfile::query()->updateOrCreate(
            ['user_id' => $request->user()->id],
            $data,
        );

        if ($request->expectsJson()) {
            return response()->json([
                'message' => __('outfit_subscription.responses.profile_saved'),
                'data' => $profile->fresh(),
            ]);
        }

        return back()->with('success', __('outfit_subscription.responses.profile_saved'));
    }

    public function store(Request $request, OutfitSubscriptionPlan $plan)
    {
        abort_unless($plan->is_active && $plan->is_public, 404);

        $availableSizes = collect($plan->sizes ?: [])
            ->map(fn ($size) => trim((string) $size))
            ->filter()
            ->values();

        $data = $request->validate([
            'accepted_terms' => ['accepted'],
            'accepted_contract' => ['accepted'],
            'payment_provider' => ['required', Rule::in(['bank_transfer', 'paypal'])],
            'selected_size' => ['nullable', 'string', 'max:60'],
            'shipping_name' => ['nullable', 'string', 'max:255'],
            'shipping_country' => ['nullable', 'string', 'size:2'],
            'shipping_street' => ['nullable', 'string', 'max:255'],
            'shipping_house_number' => ['nullable', 'string', 'max:40'],
            'shipping_postal_code' => ['nullable', 'string', 'max:30'],
            'shipping_city' => ['nullable', 'string', 'max:255'],
            'shipping_state' => ['nullable', 'string', 'max:255'],
            'shipping_note' => ['nullable', 'string', 'max:1000'],
        ], [
            'accepted_terms.accepted' => __('outfit_subscription.validation.terms_required'),
            'accepted_contract.accepted' => __('outfit_subscription.validation.contract_required'),
        ]);

        $selectedSize = filled($data['selected_size'] ?? null)
            ? trim((string) $data['selected_size'])
            : null;

        if ($availableSizes->isNotEmpty() && (! $selectedSize || ! $availableSizes->containsStrict($selectedSize))) {
            throw ValidationException::withMessages([
                'selected_size' => __('validation.in', ['attribute' => __('outfit_subscription.fields.selected_size')]),
            ]);
        }

        $existingSubscription = $request->user()
            ->outfitSubscriptions()
            ->where('outfit_subscription_plan_id', $plan->id)
            ->whereNotIn('status', ['cancelled'])
            ->first();

        if ($existingSubscription) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'plan' => __('outfit_subscription.validation.plan_already_requested'),
                ]);
            }

            return back()->with('error', __('outfit_subscription.validation.plan_already_requested'));
        }

        $paymentProvider = $data['payment_provider'] ?? 'bank_transfer';
        $bankTransfer = $this->bankTransferSettings();
        $contractSnapshot = $this->contractSnapshot($plan, $request->user(), $selectedSize);
        $shippingAddress = $this->shippingAddressFor($request, $data);
        $missingAddressFields = collect([
            'shipping_name' => 'Name',
            'shipping_country' => 'Land',
            'shipping_street' => 'Straße',
            'shipping_postal_code' => 'Postleitzahl',
            'shipping_city' => 'Stadt',
        ])->filter(fn ($label, $field) => blank($shippingAddress[$field] ?? null));

        if ($missingAddressFields->isNotEmpty()) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'shipping_address' => __('outfit_subscription.validation.shipping_address_required'),
                ]);
            }

            return back()
                ->withErrors(['shipping_address' => __('outfit_subscription.validation.shipping_address_required')])
                ->withInput();
        }

        if ($paymentProvider === 'bank_transfer' && blank($bankTransfer['iban'])) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'payment_provider' => __('outfit_subscription.validation.bank_not_configured'),
                ]);
            }

            return back()->with('error', __('outfit_subscription.validation.bank_not_configured'));
        }

        if ($paymentProvider === 'paypal') {
            $this->ensurePayPalConfigured();
        }

        $subscription = DB::transaction(function () use ($request, $plan, $paymentProvider, $shippingAddress, $contractSnapshot, $selectedSize) {
            User::query()->whereKey($request->user()->id)->lockForUpdate()->firstOrFail();

            $alreadyRequested = OutfitSubscription::query()
                ->where('user_id', $request->user()->id)
                ->where('outfit_subscription_plan_id', $plan->id)
                ->whereNotIn('status', ['cancelled', 'expired'])
                ->exists();

            if ($alreadyRequested) {
                throw ValidationException::withMessages([
                    'plan' => __('outfit_subscription.validation.plan_already_requested'),
                ]);
            }

            return OutfitSubscription::query()->create([
                'user_id' => $request->user()->id,
                'outfit_subscription_plan_id' => $plan->id,
                'sponsor_id' => $plan->sponsor_id,
                'status' => 'pending_payment',
                'payment_provider' => $paymentProvider,
                'payment_status' => 'pending',
                'monthly_price_cents' => $plan->effectiveMonthlyPriceCents(),
                'sponsor_discount_cents' => $plan->sponsor_discount_cents,
                'currency' => $plan->currency,
                'selected_size' => $selectedSize,
                ...$shippingAddress,
                'next_delivery_at' => null,
                'current_period_ends_at' => null,
                'accepted_terms_at' => now(),
                'accepted_contract_at' => now(),
                'contract_version' => $contractSnapshot['version'],
                'contract_snapshot' => $contractSnapshot,
                'accepted_ip' => $request->ip(),
                'accepted_user_agent' => Str::limit((string) $request->userAgent(), 1000, ''),
            ]);
        });

        if ($paymentProvider === 'bank_transfer') {
            $subscription->forceFill([
                'payment_reference' => $this->paymentReference($subscription),
                'payment_due_at' => now()->addDays((int) $bankTransfer['payment_terms_days'])->endOfDay(),
                'payment_payload' => ['bank_transfer' => $bankTransfer],
            ])->save();
        }

        if ($paymentProvider === 'paypal') {
            try {
                $checkoutUrl = $this->createPayPalSubscription($subscription);
            } catch (Throwable $exception) {
                $this->markOutfitCheckoutFailed($subscription);

                if ($exception instanceof ValidationException) {
                    throw $exception;
                }

                Log::warning('Outfit PayPal checkout failed unexpectedly', [
                    'subscription_id' => $subscription->id,
                    'exception' => $exception::class,
                ]);

                $this->outfitCheckoutError(__('outfit_subscription.validation.provider_checkout_failed'));
            }
            $subscription->forceFill(['checkout_url' => $checkoutUrl])->save();

            $this->notifyOutfitSubscriptionRequested($request, $plan, $subscription);

            if ($request->expectsJson()) {
                return response()->json([
                    'message' => __('outfit_subscription.responses.paypal_continue'),
                    'data' => $this->subscriptionPayload(
                        $subscription->fresh(['plan.sponsor', 'sponsor', 'deliveries']),
                    ),
                    'payment_action' => [
                        'type' => 'redirect',
                        'url' => $checkoutUrl,
                    ],
                ], 201);
            }

            return Inertia::location($checkoutUrl);
        }

        AppNotification::sendLocalized(
            $request->user(),
            'outfit.subscription.pending_payment',
            'outfit_subscription.notifications.pending_payment_title',
            'outfit_subscription.notifications.pending_payment_body',
            ['plan' => $plan->name],
            [
                'plan' => $plan->name,
                'amount_cents' => $subscription->monthly_price_cents,
                'currency' => $subscription->currency,
                'payment_provider' => $subscription->payment_provider,
                'payment_reference' => $subscription->payment_reference,
                'url' => route('auth.outfit-subscriptions.index'),
            ],
        );

        $this->notifyOutfitSubscriptionRequested($request, $plan, $subscription);

        if ($request->expectsJson()) {
            return response()->json([
                'message' => __('outfit_subscription.responses.requested'),
                'data' => $this->subscriptionPayload(
                    $subscription->fresh(['plan.sponsor', 'sponsor', 'deliveries']),
                ),
                'payment_action' => [
                    'type' => 'bank_transfer',
                    'bank_transfer' => $subscription->payment_payload['bank_transfer'] ?? null,
                    'reference' => $subscription->payment_reference,
                    'due_at' => $subscription->payment_due_at?->toJSON(),
                ],
            ], 201);
        }

        return back()->with('success', __('outfit_subscription.responses.requested_web'));
    }

    public function success(Request $request, OutfitSubscription $subscription)
    {
        $this->authorizeSubscription($request, $subscription);

        if ($subscription->payment_provider === 'paypal' && $subscription->payment_status === 'pending') {
            $this->syncPayPalSubscription($subscription, $request->query('subscription_id'));
        }

        return redirect()
            ->route('auth.outfit-subscriptions.index')
            ->with('success', __('outfit_subscription.responses.paypal_processed'));
    }

    public function cancelCheckout(Request $request, OutfitSubscription $subscription)
    {
        $this->authorizeSubscription($request, $subscription);

        $this->cancelPendingCheckout($subscription);

        return redirect()
            ->route('auth.outfit-subscriptions.index')
            ->with('success', __('outfit_subscription.responses.paypal_cancelled'));
    }

    public function paypalWebhook(Request $request)
    {
        if (! $this->isValidPayPalWebhook($request)) {
            return response('Invalid signature', 400);
        }

        $event = $request->all();
        $eventType = $event['event_type'] ?? null;
        $resource = $event['resource'] ?? [];
        $subscriptionId = $resource['billing_agreement_id']
            ?? $resource['subscription_id']
            ?? $resource['id']
            ?? null;

        if (in_array($eventType, ['BILLING.SUBSCRIPTION.ACTIVATED', 'PAYMENT.SALE.COMPLETED'], true)) {
            $subscription = OutfitSubscription::query()
                ->where('payment_provider', 'paypal')
                ->where('provider_subscription_id', $subscriptionId)
                ->first();

            if ($subscription) {
                $subscription->forceFill([
                    'payment_payload' => array_merge($subscription->payment_payload ?? [], ['paypal_webhook' => $event]),
                ])->save();

                $this->activatePaidSubscription($subscription);
            }
        }

        if (in_array($eventType, ['BILLING.SUBSCRIPTION.CANCELLED', 'BILLING.SUBSCRIPTION.SUSPENDED', 'BILLING.SUBSCRIPTION.EXPIRED'], true)) {
            $subscription = OutfitSubscription::query()
                ->where('payment_provider', 'paypal')
                ->where('provider_subscription_id', $subscriptionId)
                ->first();

            if ($subscription) {
                $isSuspended = $eventType === 'BILLING.SUBSCRIPTION.SUSPENDED';
                $paymentStatus = $subscription->payment_status;

                if (! $isSuspended && in_array($subscription->payment_status, ['pending', 'failed'], true)) {
                    $paymentStatus = 'cancelled';
                }

                $subscription->forceFill([
                    'status' => $isSuspended ? 'paused' : 'cancelled',
                    'payment_status' => $paymentStatus,
                    'cancelled_at' => $isSuspended ? $subscription->cancelled_at : now(),
                    'next_delivery_at' => $isSuspended ? $subscription->next_delivery_at : null,
                    'payment_payload' => array_merge($subscription->payment_payload ?? [], ['paypal_webhook' => $event]),
                ])->save();
            }
        }

        return response('ok');
    }

    public function pause(Request $request, OutfitSubscription $subscription)
    {
        $this->authorizeSubscription($request, $subscription);

        $pauseAllowedAt = $this->pauseAllowedAt($subscription);

        if ($pauseAllowedAt && $pauseAllowedAt->isFuture()) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'subscription' => 'Dieses Outfit-Abo kann erst ab dem '.$pauseAllowedAt->format('d.m.Y').' pausiert werden.',
                ]);
            }

            return back()->with('error', 'Dieses Outfit-Abo kann erst ab dem '.$pauseAllowedAt->format('d.m.Y').' pausiert werden.');
        }

        if ($subscription->payment_provider === 'paypal' && $subscription->provider_subscription_id) {
            $this->suspendPayPalSubscription($subscription);
        }

        $subscription->update(['status' => 'paused']);

        if ($request->expectsJson()) {
            return $this->subscriptionJsonResponse($subscription, 'Abo wurde pausiert.');
        }

        return back()->with('success', 'Abo wurde pausiert.');
    }

    public function resume(Request $request, OutfitSubscription $subscription)
    {
        $this->authorizeSubscription($request, $subscription);

        if ($subscription->payment_provider === 'paypal' && $subscription->provider_subscription_id) {
            $this->activatePayPalSubscription($subscription);
        }

        $subscription->update([
            'status' => 'active',
            'next_delivery_at' => $subscription->next_delivery_at ?: now()->addMonth()->startOfDay(),
        ]);

        if ($request->expectsJson()) {
            return $this->subscriptionJsonResponse($subscription, 'Abo wurde fortgesetzt.');
        }

        return back()->with('success', 'Abo wurde fortgesetzt.');
    }

    public function cancel(Request $request, OutfitSubscription $subscription)
    {
        $this->authorizeSubscription($request, $subscription);

        $wasPending = $subscription->status === 'pending_payment';
        $minimumTermEndsAt = $this->minimumTermEndsAt($subscription);

        if (! $wasPending && $minimumTermEndsAt && $minimumTermEndsAt->isFuture()) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'subscription' => 'Dieses Outfit-Abo kann erst nach der Mindestlaufzeit ab dem '.$minimumTermEndsAt->format('d.m.Y').' gekündigt werden.',
                ]);
            }

            return back()->with('error', 'Dieses Outfit-Abo kann erst nach der Mindestlaufzeit ab dem '.$minimumTermEndsAt->format('d.m.Y').' gekündigt werden.');
        }

        if ($wasPending) {
            $subscription->update([
                'status' => 'cancelled',
                'payment_status' => 'cancelled',
                'cancelled_at' => now(),
                'next_delivery_at' => null,
                'current_period_ends_at' => null,
            ]);

            if ($request->expectsJson()) {
                return $this->subscriptionJsonResponse($subscription, 'Outfit-Abo-Anfrage wurde abgebrochen.');
            }

            return back()->with('success', 'Outfit-Abo-Anfrage wurde abgebrochen.');
        }

        $effectiveAt = $this->cancellationEffectiveAt($subscription);

        if ($subscription->payment_provider === 'paypal' && $subscription->provider_subscription_id) {
            $this->cancelPayPalSubscription($subscription);
        }

        $subscription->update([
            'status' => $effectiveAt->isFuture() ? 'cancels_at_period_end' : 'cancelled',
            'cancelled_at' => now(),
            'current_period_ends_at' => $effectiveAt,
            'next_delivery_at' => $subscription->next_delivery_at && $subscription->next_delivery_at->lte($effectiveAt)
                ? $subscription->next_delivery_at
                : null,
        ]);

        if ($request->expectsJson()) {
            return $this->subscriptionJsonResponse(
                $subscription,
                'Outfit-Abo wurde zum '.$effectiveAt->format('d.m.Y').' gekündigt.',
            );
        }

        return back()->with('success', 'Outfit-Abo wurde zum '.$effectiveAt->format('d.m.Y').' gekündigt.');
    }

    public function requestDeliveryIssue(Request $request, OutfitDelivery $delivery)
    {
        $delivery->loadMissing(['subscription.plan', 'subscription.user']);
        $subscription = $delivery->subscription;

        abort_unless($subscription && (int) $subscription->user_id === (int) $request->user()->id, 403);

        if (! in_array($delivery->status, ['shipped', 'delivered'], true)) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'delivery' => 'Ein Problem kann erst gemeldet werden, wenn die Lieferung versendet oder zugestellt wurde.',
                ]);
            }

            return back()->with('error', 'Ein Problem kann erst gemeldet werden, wenn die Lieferung versendet oder zugestellt wurde.');
        }

        if (in_array($delivery->issue_status, ['open', 'reviewing', 'approved', 'return_waiting', 'replacement_preparing'], true)) {
            if ($request->expectsJson()) {
                throw ValidationException::withMessages([
                    'delivery' => 'Für diese Lieferung ist bereits ein offener Vorgang vorhanden.',
                ]);
            }

            return back()->with('error', 'Für diese Lieferung ist bereits ein offener Vorgang vorhanden.');
        }

        $data = $request->validate([
            'issue_type' => ['required', Rule::in(['exchange', 'return', 'damaged', 'missing_item', 'wrong_item', 'other'])],
            'issue_description' => ['required', 'string', 'max:2000'],
            'issue_requested_resolution' => ['nullable', 'string', 'max:1000'],
            'issue_exchange_size' => ['nullable', 'string', 'max:60'],
        ]);

        $delivery->forceFill([
            'issue_type' => $data['issue_type'],
            'issue_status' => 'open',
            'issue_description' => trim($data['issue_description']),
            'issue_requested_resolution' => filled($data['issue_requested_resolution'] ?? null) ? trim($data['issue_requested_resolution']) : null,
            'issue_exchange_size' => filled($data['issue_exchange_size'] ?? null) ? trim($data['issue_exchange_size']) : null,
            'issue_admin_note' => null,
            'return_tracking_number' => null,
            'return_tracking_url' => null,
            'issue_requested_at' => now(),
            'issue_resolved_at' => null,
        ])->save();

        $this->notifyOutfitDeliveryIssueRequested($request, $delivery->fresh(['subscription.plan']));

        if ($request->expectsJson()) {
            return response()->json([
                'message' => __('outfit_subscription.responses.issue_sent'),
                'data' => $delivery->fresh(),
            ], 201);
        }

        return back()->with('success', __('outfit_subscription.responses.issue_sent_web'));
    }

    private function subscriptionJsonResponse(
        OutfitSubscription $subscription,
        string $message,
    ) {
        return response()->json([
            'message' => $message,
            'data' => $this->subscriptionPayload(
                $subscription->fresh(['plan.sponsor', 'sponsor', 'deliveries']),
            ),
        ]);
    }

    private function authorizeSubscription(Request $request, OutfitSubscription $subscription): void
    {
        abort_unless((int) $subscription->user_id === (int) $request->user()->id, 403);
    }

    private function pauseAllowedAt(OutfitSubscription $subscription)
    {
        $months = (int) $this->contractRules($subscription->plan)['pause_allowed_after_months'];

        if ($months <= 0) {
            return null;
        }

        return ($subscription->accepted_contract_at ?: $subscription->created_at)?->copy()->addMonthsNoOverflow($months);
    }

    private function minimumTermEndsAt(OutfitSubscription $subscription)
    {
        $months = (int) $this->contractRules($subscription->plan)['minimum_term_months'];

        if ($months <= 0) {
            return null;
        }

        return ($subscription->accepted_contract_at ?: $subscription->created_at)?->copy()->addMonthsNoOverflow($months);
    }

    private function cancellationEffectiveAt(OutfitSubscription $subscription)
    {
        $noticeEnd = now()->addDays((int) $this->contractRules($subscription->plan)['cancellation_notice_days']);
        $periodEnd = $subscription->current_period_ends_at && $subscription->current_period_ends_at->isFuture()
            ? $subscription->current_period_ends_at
            : now();

        return $periodEnd->greaterThan($noticeEnd) ? $periodEnd->copy() : $noticeEnd;
    }

    private function planPayload(OutfitSubscriptionPlan $plan): array
    {
        return [
            'id' => $plan->id,
            'name' => $plan->name,
            'slug' => $plan->slug,
            'description' => $plan->description,
            'contract_title' => $plan->contract_title,
            'contract_terms' => $plan->contract_terms ?: [],
            'contract_rules' => $this->contractRules($plan),
            'monthly_price_cents' => $plan->monthly_price_cents,
            'sponsor_discount_cents' => $plan->sponsor_discount_cents,
            'effective_monthly_price_cents' => $plan->effectiveMonthlyPriceCents(),
            'currency' => $plan->currency,
            'target_gender' => $plan->target_gender,
            'sizes' => $plan->sizes ?: [],
            'sports' => $plan->sports ?: [],
            'items_per_box' => $plan->items_per_box,
            'branding_type' => $plan->branding_type,
            'sponsor' => $plan->sponsor ? [
                'id' => $plan->sponsor->id,
                'name' => $plan->sponsor->name,
                'logo' => $plan->sponsor->logo,
                'logo_url' => UploadStorage::url($plan->sponsor->logo),
                'logo_light_url' => UploadStorage::url($plan->sponsor->logo_light ?: $plan->sponsor->logo),
                'logo_dark_url' => UploadStorage::url($plan->sponsor->logo_dark ?: $plan->sponsor->logo_light ?: $plan->sponsor->logo),
                'website' => $plan->sponsor->website,
            ] : null,
        ];
    }

    private function subscriptionPayload(OutfitSubscription $subscription): array
    {
        $bankTransfer = $subscription->payment_provider === 'bank_transfer'
            ? ($subscription->payment_payload['bank_transfer'] ?? $this->bankTransferSettings())
            : null;

        return [
            'id' => $subscription->id,
            'status' => $subscription->status,
            'payment_provider' => $subscription->payment_provider,
            'payment_status' => $subscription->payment_status,
            'payment_reference' => $subscription->payment_reference ?: $this->paymentReference($subscription),
            'payment_due_at' => $subscription->payment_due_at ?: $subscription->created_at?->copy()->addDays((int) Setting::valueFor('billing_payment_terms_days', 14))->endOfDay(),
            'dunning_level' => (int) $subscription->dunning_level,
            'last_dunning_sent_at' => $subscription->last_dunning_sent_at,
            'payment_paused_at' => $subscription->payment_paused_at,
            'payment_paused_reason' => $subscription->payment_paused_reason,
            'bank_transfer' => $bankTransfer,
            'monthly_price_cents' => $subscription->monthly_price_cents,
            'sponsor_discount_cents' => $subscription->sponsor_discount_cents,
            'currency' => $subscription->currency,
            'selected_size' => $subscription->selected_size,
            'next_delivery_at' => $subscription->next_delivery_at,
            'current_period_ends_at' => $subscription->current_period_ends_at,
            'cancelled_at' => $subscription->cancelled_at,
            'shipping_address' => $this->shippingAddressPayload($subscription),
            'plan' => $subscription->plan ? $this->planPayload($subscription->plan) : null,
            'sponsor' => $subscription->sponsor,
            'deliveries' => $subscription->deliveries,
            'accepted_contract_at' => $subscription->accepted_contract_at,
            'contract_version' => $subscription->contract_version,
        ];
    }

    private function shippingAddressFor(Request $request, array $data): array
    {
        $user = $request->user();

        $address = [
            'shipping_name' => $data['shipping_name'] ?? $user->name,
            'shipping_country' => $data['shipping_country'] ?? $user->country ?? 'DE',
            'shipping_street' => $data['shipping_street'] ?? $user->street,
            'shipping_house_number' => $data['shipping_house_number'] ?? $user->house_number,
            'shipping_postal_code' => $data['shipping_postal_code'] ?? $user->postal_code,
            'shipping_city' => $data['shipping_city'] ?? $user->city,
            'shipping_state' => $data['shipping_state'] ?? $user->state,
            'shipping_note' => $data['shipping_note'] ?? null,
        ];

        return collect($address)
            ->map(fn ($value, $key) => $key === 'shipping_country'
                ? strtoupper(Str::limit(trim((string) $value), 2, ''))
                : (filled($value) ? trim((string) $value) : null))
            ->all();
    }

    private function shippingAddressPayload(OutfitSubscription $subscription): array
    {
        return [
            'name' => $subscription->shipping_name,
            'country' => $subscription->shipping_country,
            'street' => $subscription->shipping_street,
            'house_number' => $subscription->shipping_house_number,
            'postal_code' => $subscription->shipping_postal_code,
            'city' => $subscription->shipping_city,
            'state' => $subscription->shipping_state,
            'note' => $subscription->shipping_note,
        ];
    }

    private function contractRules(?OutfitSubscriptionPlan $plan): array
    {
        return [
            'version' => 'outfit-abo-plan-v1-2026-05-09',
            'minimum_term_months' => (int) ($plan?->minimum_term_months ?? Setting::valueFor('outfit_minimum_term_months', 3)),
            'pause_allowed_after_months' => (int) ($plan?->pause_allowed_after_months ?? Setting::valueFor('outfit_pause_allowed_after_months', 3)),
            'cancellation_notice_days' => (int) ($plan?->cancellation_notice_days ?? Setting::valueFor('outfit_cancellation_notice_days', 14)),
            'changes_locked_after_shipping_preparation' => true,
        ];
    }

    private function contractSnapshot(OutfitSubscriptionPlan $plan, User $user, ?string $selectedSize): array
    {
        $rules = $this->contractRules($plan);
        $terms = $plan->contract_terms ?: [
            'Das Outfit-Abo ist ein monatliches Abonnement mit wiederkehrender Zahlung.',
            'Die erste Lieferung wird erst nach bestätigter Zahlung vorbereitet.',
            'Pause und Kündigung gelten nur für zukünftige Lieferungen.',
            'Bereits vorbereitete, versendete oder zugestellte Boxen bleiben kostenpflichtig.',
            'Bei PayPal wird der Monatsbetrag automatisch wiederkehrend eingezogen, bis die Pause oder Kündigung wirksam ist.',
        ];

        return array_merge($rules, [
            'accepted_at' => now()->toIso8601String(),
            'contract_title' => $plan->contract_title ?: 'Outfit-Abo-Vertrag '.$plan->name,
            'customer' => [
                'id' => $user->id,
                'name' => $user->name,
                'email' => $user->email,
            ],
            'plan_id' => $plan->id,
            'plan_name' => $plan->name,
            'monthly_price_cents' => $plan->effectiveMonthlyPriceCents(),
            'currency' => $plan->currency,
            'items_per_box' => $plan->items_per_box,
            'selected_size' => $selectedSize,
            'sponsor_discount_cents' => $plan->sponsor_discount_cents,
            'terms' => $terms,
            'personalized_summary' => sprintf(
                '%s (%s) akzeptiert den Vertrag "%s" für den Plan "%s" zum Monatsbetrag von %.2f %s.',
                $user->name,
                $user->email,
                $plan->contract_title ?: 'Outfit-Abo-Vertrag '.$plan->name,
                $plan->name,
                $plan->effectiveMonthlyPriceCents() / 100,
                strtoupper($plan->currency)
            ),
        ]);
    }

    private function paymentReference(OutfitSubscription $subscription): string
    {
        return 'AIR-OUT-'.$subscription->created_at->format('Y').'-'.str_pad((string) $subscription->id, 6, '0', STR_PAD_LEFT);
    }

    private function bankTransferSettings(): array
    {
        return [
            'bank_account_holder' => Setting::valueFor('billing_bank_account_holder', 'Airmius'),
            'bank_name' => Setting::valueFor('billing_bank_name', ''),
            'iban' => Setting::valueFor('billing_iban', ''),
            'bic' => Setting::valueFor('billing_bic', ''),
            'payment_terms_days' => (int) Setting::valueFor('billing_payment_terms_days', 14),
        ];
    }

    private function createPayPalSubscription(OutfitSubscription $subscription): string
    {
        $subscription->loadMissing('plan', 'user');

        $amountCents = max(0, (int) $subscription->monthly_price_cents);
        if ($amountCents <= 0) {
            $this->outfitCheckoutError(__('outfit_subscription.validation.free_checkout'));
        }

        $planId = $this->ensurePayPalPlan($subscription->plan, $amountCents, $subscription->currency);

        $response = Http::withToken($this->paypalAccessToken())->post($this->paypalBaseUrl().'/v1/billing/subscriptions', [
            'plan_id' => $planId,
            'custom_id' => 'airmius-outfit-'.$subscription->id,
            'quantity' => '1',
            'subscriber' => [
                'email_address' => $subscription->user?->email,
                'name' => [
                    'given_name' => Str::of((string) $subscription->user?->name)->explode(' ')->first() ?: 'Airmius',
                    'surname' => Str::of((string) $subscription->user?->name)->explode(' ')->slice(1)->implode(' ') ?: 'Kunde',
                ],
            ],
            'application_context' => [
                'brand_name' => 'Airmius',
                'user_action' => 'SUBSCRIBE_NOW',
                'return_url' => route('outfit-subscription-checkout.success', $subscription),
                'cancel_url' => $this->outfitCancelUrl($subscription),
            ],
        ]);

        if ($response->failed()) {
            Log::warning('Outfit PayPal checkout failed', [
                'subscription_id' => $subscription->id,
                'status' => $response->status(),
            ]);
            $this->outfitCheckoutError(__('outfit_subscription.validation.provider_checkout_failed'));
        }

        $payload = $response->json();
        $subscription->forceFill([
            'payment_reference' => $this->paymentReference($subscription),
            'provider_subscription_id' => $payload['id'] ?? null,
            'provider_checkout_id' => $payload['id'] ?? null,
            'payment_payload' => array_merge($subscription->payment_payload ?? [], ['paypal_subscription' => $payload]),
        ])->save();

        $approveLink = collect($payload['links'] ?? [])->firstWhere('rel', 'approve');
        if (blank($approveLink['href'] ?? null)) {
            $this->outfitCheckoutError(__('outfit_subscription.validation.paypal_approval_missing'));
        }

        return $approveLink['href'];
    }

    private function ensurePayPalPlan(OutfitSubscriptionPlan $plan, int $amountCents, string $currency): string
    {
        $signature = hash('sha256', implode('|', [
            config('services.paypal.mode'),
            $plan->id,
            $amountCents,
            strtoupper($currency),
            'MONTH',
            1,
        ]));

        if ($plan->paypal_plan_id && $plan->paypal_plan_signature === $signature) {
            return $plan->paypal_plan_id;
        }

        $productId = $plan->paypal_product_id ?: $this->createPayPalProduct($plan);
        $amount = number_format($amountCents / 100, 2, '.', '');

        $response = Http::withToken($this->paypalAccessToken())->post($this->paypalBaseUrl().'/v1/billing/plans', [
            'product_id' => $productId,
            'name' => 'Airmius Outfit-Abo '.$plan->name.' '.strtoupper($currency).' '.$amount,
            'description' => Str::limit($plan->description ?: 'Monatliches Airmius Outfit-Abo', 120),
            'status' => 'ACTIVE',
            'billing_cycles' => [[
                'frequency' => [
                    'interval_unit' => 'MONTH',
                    'interval_count' => 1,
                ],
                'tenure_type' => 'REGULAR',
                'sequence' => 1,
                'total_cycles' => 0,
                'pricing_scheme' => [
                    'fixed_price' => [
                        'value' => $amount,
                        'currency_code' => strtoupper($currency),
                    ],
                ],
            ]],
            'payment_preferences' => [
                'auto_bill_outstanding' => true,
                'setup_fee_failure_action' => 'CONTINUE',
                'payment_failure_threshold' => 3,
            ],
        ]);

        if ($response->failed()) {
            Log::warning('Outfit PayPal plan failed', [
                'plan_id' => $plan->id,
                'status' => $response->status(),
            ]);
            $this->outfitCheckoutError(__('outfit_subscription.validation.paypal_plan_failed'));
        }

        $payload = $response->json();
        $plan->forceFill([
            'paypal_product_id' => $productId,
            'paypal_plan_id' => $payload['id'] ?? null,
            'paypal_plan_signature' => $signature,
            'paypal_payload' => array_merge($plan->paypal_payload ?? [], ['plan' => $payload]),
        ])->save();

        return $plan->paypal_plan_id;
    }

    private function createPayPalProduct(OutfitSubscriptionPlan $plan): string
    {
        $response = Http::withToken($this->paypalAccessToken())->post($this->paypalBaseUrl().'/v1/catalogs/products', [
            'name' => 'Airmius Outfit-Abo '.$plan->name,
            'description' => Str::limit($plan->description ?: 'Monatliches Airmius Outfit-Abo', 120),
            'type' => 'SERVICE',
        ]);

        if ($response->failed()) {
            Log::warning('Outfit PayPal product failed', [
                'plan_id' => $plan->id,
                'status' => $response->status(),
            ]);
            $this->outfitCheckoutError(__('outfit_subscription.validation.paypal_product_failed'));
        }

        $payload = $response->json();
        $plan->forceFill([
            'paypal_product_id' => $payload['id'] ?? null,
            'paypal_payload' => array_merge($plan->paypal_payload ?? [], ['product' => $payload]),
        ])->save();

        return $plan->paypal_product_id;
    }

    private function syncPayPalSubscription(OutfitSubscription $subscription, ?string $subscriptionId = null): void
    {
        $providerSubscriptionId = $subscriptionId ?: $subscription->provider_subscription_id;

        if (! $providerSubscriptionId) {
            return;
        }

        $response = Http::withToken($this->paypalAccessToken())
            ->get($this->paypalBaseUrl().'/v1/billing/subscriptions/'.$providerSubscriptionId);

        if ($response->ok()) {
            $subscription->forceFill([
                'provider_subscription_id' => $providerSubscriptionId,
                'provider_checkout_id' => $providerSubscriptionId,
                'payment_payload' => array_merge($subscription->payment_payload ?? [], ['paypal_subscription_sync' => $response->json()]),
            ])->save();
        }

        if ($response->ok() && $response->json('status') === 'ACTIVE') {
            $this->activatePaidSubscription($subscription);
        }
    }

    private function cancelPayPalSubscription(OutfitSubscription $subscription): void
    {
        try {
            Http::withToken($this->paypalAccessToken())
                ->withBody(json_encode(['reason' => 'Airmius Outfit-Abo wurde vom Kunden beendet.']), 'application/json')
                ->post($this->paypalBaseUrl().'/v1/billing/subscriptions/'.$subscription->provider_subscription_id.'/cancel');
        } catch (Throwable $exception) {
            Log::warning('Outfit PayPal subscription cancel failed', [
                'subscription_id' => $subscription->id,
                'paypal_subscription_id' => $subscription->provider_subscription_id,
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function suspendPayPalSubscription(OutfitSubscription $subscription): void
    {
        try {
            Http::withToken($this->paypalAccessToken())
                ->withBody(json_encode(['reason' => 'Airmius Outfit-Abo wurde vom Kunden pausiert.']), 'application/json')
                ->post($this->paypalBaseUrl().'/v1/billing/subscriptions/'.$subscription->provider_subscription_id.'/suspend');
        } catch (Throwable $exception) {
            Log::warning('Outfit PayPal subscription suspend failed', [
                'subscription_id' => $subscription->id,
                'paypal_subscription_id' => $subscription->provider_subscription_id,
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function activatePayPalSubscription(OutfitSubscription $subscription): void
    {
        try {
            Http::withToken($this->paypalAccessToken())
                ->withBody(json_encode(['reason' => 'Airmius Outfit-Abo wurde vom Kunden fortgesetzt.']), 'application/json')
                ->post($this->paypalBaseUrl().'/v1/billing/subscriptions/'.$subscription->provider_subscription_id.'/activate');
        } catch (Throwable $exception) {
            Log::warning('Outfit PayPal subscription activate failed', [
                'subscription_id' => $subscription->id,
                'paypal_subscription_id' => $subscription->provider_subscription_id,
                'message' => $exception->getMessage(),
            ]);
        }
    }

    private function activatePaidSubscription(OutfitSubscription $subscription): void
    {
        if ($subscription->payment_status === 'paid') {
            return;
        }

        $subscription->forceFill([
            'status' => 'active',
            'payment_status' => 'paid',
            'dunning_level' => 0,
            'last_dunning_sent_at' => null,
            'payment_paused_at' => null,
            'payment_paused_reason' => null,
            'payment_due_at' => null,
            'next_delivery_at' => $subscription->next_delivery_at ?? now()->addMonth()->startOfDay(),
            'current_period_ends_at' => $subscription->current_period_ends_at ?? now()->addMonth(),
            'cancelled_at' => null,
        ])->save();

        if (! $subscription->deliveries()->exists()) {
            $subscription->deliveries()->create([
                'status' => 'planned',
                'delivery_month' => now()->addMonth()->startOfMonth(),
                'items' => [],
                'notes' => 'PayPal-Zahlung bestätigt. Erste personalisierte Box wird vorbereitet.',
            ]);
        }

        $subscription->loadMissing(['plan', 'user']);

        app(OutfitInvoiceService::class)->createPaidInvoice($subscription->fresh(['plan', 'sponsor']));

        AppNotification::sendLocalized(
            $subscription->user,
            'outfit.subscription.paid',
            'outfit_subscription.notifications.paid_title',
            'outfit_subscription.notifications.paid_body',
            ['plan' => $subscription->plan?->name],
            [
                'url' => route('auth.outfit-subscriptions.index'),
                'subscription_id' => $subscription->id,
            ],
        );
    }

    private function notifyOutfitSubscriptionRequested(Request $request, OutfitSubscriptionPlan $plan, OutfitSubscription $subscription): void
    {
        $this->outfitAdminRecipients()
            ->each(function (User $admin) use ($request, $plan, $subscription) {
                AppNotification::sendLocalized(
                    $admin,
                    'outfit.subscription.requested',
                    'outfit_subscription.notifications.requested_title',
                    'outfit_subscription.notifications.requested_body',
                    ['user' => $request->user()->name, 'plan' => $plan->name],
                    [
                        'user_id' => $request->user()->id,
                        'user_name' => $request->user()->name,
                        'plan' => $plan->name,
                        'subscription_id' => $subscription->id,
                        'amount_cents' => $subscription->monthly_price_cents,
                        'currency' => $subscription->currency,
                        'payment_provider' => $subscription->payment_provider,
                        'payment_reference' => $subscription->payment_reference,
                        'url' => route('admin.outfit-subscriptions.index'),
                    ],
                );
            });
    }

    private function notifyOutfitDeliveryIssueRequested(Request $request, OutfitDelivery $delivery): void
    {
        $admins = $this->outfitAdminRecipients();

        $admins->each(function (User $admin) use ($request, $delivery) {
            AppNotification::sendLocalized(
                $admin,
                'outfit.delivery.issue_requested',
                'outfit_subscription.notifications.issue_requested_title',
                'outfit_subscription.notifications.issue_requested_body',
                ['user' => $request->user()->name],
                [
                    'user_id' => $request->user()->id,
                    'user_name' => $request->user()->name,
                    'delivery_id' => $delivery->id,
                    'subscription_id' => $delivery->outfit_subscription_id,
                    'issue_type' => $delivery->issue_type,
                    'issue_status' => $delivery->issue_status,
                    'url' => route('admin.outfit-subscriptions.index'),
                ],
            );
        });
    }

    private function outfitAdminRecipients()
    {
        $roleNames = array_unique(array_merge(Roles::FULL_ACCESS, Roles::MARKETPLACE_OPERATIONS));
        $permissionNames = [
            'outfit-subscriptions.manage',
            'marketplace.manage',
            'commerce.orders.manage',
            'subscriptions.manage',
            'billing.manage',
            'finance.edit',
        ];

        $existingRoleNames = Role::query()
            ->whereIn('name', $roleNames)
            ->pluck('name')
            ->all();
        $existingPermissionNames = Permission::query()
            ->whereIn('name', $permissionNames)
            ->pluck('name')
            ->all();

        $admins = collect();

        if ($existingRoleNames) {
            $admins = $admins->merge(User::role($existingRoleNames)->get(['id', 'name', 'email', 'language']));
        }

        if ($existingPermissionNames) {
            $admins = $admins->merge(User::permission($existingPermissionNames)->get(['id', 'name', 'email', 'language']));
        }

        return $admins->unique('id')->values();
    }

    private function paypalAccessToken(): string
    {
        $this->ensurePayPalConfigured();

        $response = Http::asForm()
            ->withBasicAuth(config('services.paypal.client_id'), config('services.paypal.client_secret'))
            ->post($this->paypalBaseUrl().'/v1/oauth2/token', ['grant_type' => 'client_credentials']);

        if ($response->failed()) {
            $this->outfitCheckoutError(__('outfit_subscription.validation.paypal_token_failed'));
        }

        return $response->json('access_token');
    }

    private function ensurePayPalConfigured(): void
    {
        if (blank(config('services.paypal.client_id')) || blank(config('services.paypal.client_secret'))) {
            $this->outfitCheckoutError(__('outfit_subscription.validation.provider_not_configured'));
        }
    }

    private function outfitCancelUrl(OutfitSubscription $subscription): string
    {
        return URL::temporarySignedRoute(
            'outfit-subscription-checkout.cancel',
            now()->addDay(),
            ['subscription' => $subscription],
        );
    }

    private function cancelPendingCheckout(OutfitSubscription $subscription): void
    {
        DB::transaction(function () use ($subscription) {
            $lockedSubscription = OutfitSubscription::query()
                ->lockForUpdate()
                ->findOrFail($subscription->id);

            if ($lockedSubscription->payment_status === 'cancelled') {
                return;
            }

            abort_unless(
                $lockedSubscription->status === 'pending_payment' && $lockedSubscription->payment_status === 'pending',
                422,
                __('outfit_subscription.validation.checkout_not_cancellable'),
            );

            $lockedSubscription->forceFill([
                'status' => 'cancelled',
                'payment_status' => 'cancelled',
                'checkout_url' => null,
                'cancelled_at' => now(),
                'payment_payload' => array_merge($lockedSubscription->payment_payload ?? [], [
                    'checkout_cancelled_at' => now()->toISOString(),
                ]),
            ])->save();
        });

        $subscription->refresh();
    }

    private function markOutfitCheckoutFailed(OutfitSubscription $subscription): void
    {
        DB::transaction(function () use ($subscription) {
            $lockedSubscription = OutfitSubscription::query()
                ->lockForUpdate()
                ->findOrFail($subscription->id);

            if ($lockedSubscription->status !== 'pending_payment' || $lockedSubscription->payment_status !== 'pending') {
                return;
            }

            $lockedSubscription->forceFill([
                'payment_status' => 'failed',
                'checkout_url' => null,
                'payment_payload' => array_merge($lockedSubscription->payment_payload ?? [], [
                    'provider_failed_at' => now()->toISOString(),
                ]),
            ])->save();
        });

        $subscription->refresh();
    }

    private function outfitCheckoutError(string $message): never
    {
        throw ValidationException::withMessages([
            'payment_provider' => $message,
        ]);
    }

    private function paypalBaseUrl(): string
    {
        return config('services.paypal.mode') === 'live'
            ? 'https://api-m.paypal.com'
            : 'https://api-m.sandbox.paypal.com';
    }

    private function isValidPayPalWebhook(Request $request): bool
    {
        $webhookId = config('services.paypal.outfit_webhook_id') ?: config('services.paypal.webhook_id');

        return app(PaymentWebhookVerifier::class)->isValidPayPalWebhook($request, $webhookId);
    }
}
