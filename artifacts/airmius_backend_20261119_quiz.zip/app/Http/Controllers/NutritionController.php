<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Concerns\ManagesNutritionPayloads;
use App\Http\Resources\Api\V1\NutritionGoalResource;
use App\Http\Resources\Api\V1\NutritionMealResource;
use App\Models\NutritionGoal;
use App\Models\NutritionMeal;
use App\Models\TrainingLog;
use App\Services\Ai\AirmiusAiService;
use App\Services\NutritionFoodLookupService;
use App\Services\NutritionPremiumFeatureService;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Inertia\Inertia;
use RuntimeException;

class NutritionController extends Controller
{
    use ManagesNutritionPayloads;

    public function index(Request $request, AirmiusAiService $ai, NutritionPremiumFeatureService $premium)
    {
        $user = $request->user();
        $date = $request->date('date')?->toDateString() ?? now()->toDateString();
        $goal = NutritionGoal::query()->firstOrCreate(
            ['user_id' => $user->id],
            [
                'goal_type' => 'maintain',
                'diet_style' => 'balanced',
                'daily_calories_target' => 2200,
                'protein_target_g' => 120,
                'carbs_target_g' => 260,
                'fat_target_g' => 75,
                'water_target_ml' => 2500,
                'water_target_mode' => 'auto',
            ],
        );

        $meals = NutritionMeal::query()
            ->forUser($user)
            ->whereDate('eaten_on', $date)
            ->latest('created_at')
            ->get();

        $recentTraining = TrainingLog::query()
            ->where('user_id', $user->id)
            ->latest('performed_at')
            ->latest('id')
            ->limit(4)
            ->get(['id', 'title', 'sport_type', 'performed_at', 'duration_minutes', 'calories', 'intensity']);

        return Inertia::render('Auth/Dashboard/Nutrition/Index', [
            'selectedDate' => $date,
            'goal' => (new NutritionGoalResource($goal))->resolve(),
            'meals' => NutritionMealResource::collection($meals)->resolve(),
            'todaySummary' => $this->summaryForDate($user, $date),
            'weeklySummaries' => $this->weeklySummaries($user, $date),
            'waterRecommendation' => $this->waterRecommendation($user, $goal, $date),
            'catalog' => $this->nutritionCatalog(),
            'recipes' => $this->nutritionRecipes($goal->goal_type, $goal->diet_style),
            'tips' => $this->nutritionTips($goal->goal_type),
            'trainingSuggestions' => $this->trainingNutritionSuggestions($recentTraining, $goal->goal_type),
            'aiCapabilities' => $ai->capabilities($user),
            'nutritionAccess' => $premium->capabilities($user),
            'recentTraining' => $recentTraining->map(fn (TrainingLog $log) => [
                'id' => $log->id,
                'title' => $log->title,
                'sport_type' => $log->sport_type,
                'performed_at' => $log->performed_at?->toIso8601String(),
                'duration_minutes' => $log->duration_minutes,
                'calories' => $log->calories,
                'intensity' => $log->intensity,
            ])->values(),
        ]);
    }

    public function updateGoal(Request $request)
    {
        $timezone = $this->validatedWaterReminderTimezone($request);
        $data = $this->validateGoalData($request);
        $goal = NutritionGoal::query()->updateOrCreate(
            ['user_id' => $request->user()->id],
            $data,
        );
        if ($timezone !== null) {
            $request->user()->forceFill(['timezone' => $timezone])->save();
        }

        return back()->with('success', __('nutrition.responses.goal_saved'));
    }

    public function searchFoods(Request $request, NutritionFoodLookupService $lookup, NutritionPremiumFeatureService $premium)
    {
        $data = $request->validate([
            'q' => ['required', 'string', 'min:2', 'max:80'],
        ]);

        return response()->json([
            'data' => collect($lookup->search($data['q']))
                ->map(fn (array $product) => $premium->filterProduct($product, $request->user()))
                ->values()
                ->all(),
        ]);
    }

    public function lookupBarcode(Request $request, NutritionFoodLookupService $lookup, NutritionPremiumFeatureService $premium)
    {
        $data = $request->validate([
            'barcode' => ['required', 'string', 'min:6', 'max:32', 'regex:/^[0-9\\s\\-]+$/'],
        ]);

        $product = $lookup->barcode($data['barcode']);

        if (! $product) {
            return response()->json([
                'message' => __('nutrition.responses.product_not_found'),
            ], 404);
        }

        return response()->json([
            'data' => $premium->filterProduct($product, $request->user()),
        ]);
    }

    public function analyzeMealImage(Request $request, AirmiusAiService $ai)
    {
        $data = $request->validate([
            'image' => ['required', 'image', 'mimes:jpg,jpeg,png,webp', 'max:'.(int) config('airmius_ai.privacy.max_image_kb', 5120)],
            'ai_consent' => ['accepted'],
            'meal_type' => ['nullable', 'string', 'max:40'],
            'diet_style' => ['nullable', 'string', 'max:40'],
        ]);

        try {
            $suggestion = $ai->analyzeNutritionImage($request->user(), $data['image'], [
                'meal_type' => $data['meal_type'] ?? null,
                'diet_style' => $data['diet_style'] ?? null,
            ]);
        } catch (RuntimeException $exception) {
            return response()->json([
                'message' => $exception->getMessage(),
            ], 422);
        }

        return response()->json([
            'data' => $suggestion,
            'message' => __('nutrition.responses.ai_suggestion_created'),
        ]);
    }

    public function storeMeal(Request $request)
    {
        $meal = NutritionMeal::query()->create(
            $this->mealPayload($request->user(), $this->validateMealData($request))
        );

        return back()->with('success', __('nutrition.responses.meal_saved_named', ['meal' => $meal->title]));
    }

    public function storeWater(Request $request)
    {
        $entry = NutritionMeal::query()->create(
            $this->waterPayload($request->user(), $this->validateWaterData($request))
        );

        return back()->with([
            'success' => __('nutrition.responses.water_logged', ['amount' => $entry->water_ml]),
            'flash_id' => (string) Str::uuid(),
        ]);
    }

    public function updateMeal(Request $request, NutritionMeal $nutritionMeal)
    {
        abort_unless((int) $nutritionMeal->user_id === (int) $request->user()->id, 403);

        $nutritionMeal->update(
            $this->mealPayload($request->user(), $this->validateMealData($request, true), $nutritionMeal)
        );

        return back()->with('success', __('nutrition.responses.meal_updated'));
    }

    public function destroyMeal(Request $request, NutritionMeal $nutritionMeal)
    {
        abort_unless((int) $nutritionMeal->user_id === (int) $request->user()->id, 403);

        $nutritionMeal->delete();

        return back()->with('success', __('nutrition.responses.meal_deleted'));
    }
}
